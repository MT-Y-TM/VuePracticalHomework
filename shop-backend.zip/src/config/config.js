// default config
module.exports = {
  workers: 1,
  // 自定义配置
  userConfig: {
    // 静态资源地址前缀
    staticURL: 'http://127.0.0.1:8360/'
  }
};
